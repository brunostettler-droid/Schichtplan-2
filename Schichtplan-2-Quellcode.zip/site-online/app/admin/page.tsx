import { requireChatGPTUser } from '@/app/chatgpt-auth';
import { isAdmin } from '@/lib/admin';
import Home from '../page';
export const dynamic='force-dynamic';
export default async function Page(){await requireChatGPTUser('/admin');if(!await isAdmin())return <main className="sheet-page"><p>Dieser Bereich ist nur für den Administrator.</p></main>;return <Home administrator/>}
