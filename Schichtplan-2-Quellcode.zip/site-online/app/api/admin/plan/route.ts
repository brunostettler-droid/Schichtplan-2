import { database } from '@/db';
import { closureReason } from '@/lib/closures';
import { isAdmin } from '@/lib/admin';
export const dynamic='force-dynamic';
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){if(!await isAdmin())return reply({error:'Nur der Administrator hat Zugriff.'},403);try{const db=await database();const {results}=await db.prepare('SELECT id,date,period,role,time,position,name,fixed,disabled,updated FROM shifts ORDER BY date,position').all();const staff=await db.prepare('SELECT name FROM employees ORDER BY name COLLATE NOCASE').all<{name:string}>();return reply({shifts:results.map(s=>({...s,closureReason:closureReason(String(s.date),String(s.period))})),employees:staff.results.map(x=>x.name),checkedAt:new Date().toISOString()});}catch(e){console.error(e);return reply({error:'Plan konnte nicht geladen werden.'},503)}}
export async function POST(req:Request){
 if(!await isAdmin())return reply({error:'Nur der Administrator darf Schichten ändern.'},403);
 if(req.headers.get('Origin')!==new URL(req.url).origin)return reply({error:'Ungültige Anfrage.'},403);
 try{const raw=await req.text();if(raw.length>2000)return reply({error:'Eingabe zu lang.'},400);const b=JSON.parse(raw);
 const db=await database(),now=new Date().toISOString();
 if(['addEmployee','deleteEmployee'].includes(b.action)){
  const name=typeof b.name==='string'?b.name.trim().replace(/\s+/g,' '):'';
  if(name.length<2||name.length>40||/[\x00-\x1F<>]/.test(name))return reply({error:'Bitte einen Namen mit 2 bis 40 Zeichen eingeben.'},400);
  const r=b.action==='addEmployee'?await db.prepare('INSERT INTO employees(name) SELECT ? WHERE NOT EXISTS (SELECT 1 FROM employees WHERE lower(name)=lower(?))').bind(name,name).run():await db.prepare('DELETE FROM employees WHERE name=?').bind(name).run();
  if(!r.meta.changes)return reply({error:b.action==='addEmployee'?'Dieser Name ist bereits vorhanden.':'Mitarbeiter nicht gefunden.'},409);return reply({ok:true});
 }
 if(!['assign','swap'].includes(b.action)||typeof b.id!=='string'||typeof b.updated!=='string')return reply({error:'Ungültige Eingabe.'},400);
 if(b.action==='assign'){
  if(b.name!==null&&(typeof b.name!=='string'||!await db.prepare('SELECT name FROM employees WHERE name=?').bind(b.name).first()))return reply({error:'Unbekannter Mitarbeiter.'},400);
  const r=await db.prepare('UPDATE shifts SET name=?,owner=NULL,updated=? WHERE id=? AND updated=? AND disabled=0').bind(b.name,now,b.id,b.updated).run();
  if(!r.meta.changes)return reply({error:'Die Schicht wurde inzwischen geändert. Bitte neu laden.'},409);
 }else{
  if(typeof b.otherId!=='string'||typeof b.otherUpdated!=='string'||b.id===b.otherId)return reply({error:'Bitte zwei verschiedene Schichten wählen.'},400);
  const first=await db.prepare('SELECT name FROM shifts WHERE id=? AND updated=? AND disabled=0').bind(b.id,b.updated).first<{name:string|null}>();
  const second=await db.prepare('SELECT name FROM shifts WHERE id=? AND updated=? AND disabled=0').bind(b.otherId,b.otherUpdated).first<{name:string|null}>();
  if(!first||!second)return reply({error:'Schichten wurden inzwischen geändert. Bitte neu laden.'},409);
  const r=await db.prepare(`UPDATE shifts SET name=CASE WHEN id=? THEN ? ELSE ? END,owner=NULL,updated=? WHERE id IN (?,?) AND disabled=0 AND (SELECT COUNT(*) FROM shifts WHERE (id=? AND updated=?) OR (id=? AND updated=?))=2`).bind(b.id,second.name,first.name,now,b.id,b.otherId,b.id,b.updated,b.otherId,b.otherUpdated).run();
  if(r.meta.changes!==2)return reply({error:'Schichten wurden inzwischen geändert. Bitte neu laden.'},409);
 }
 return reply({ok:true});
 }catch(e){console.error(e);return reply({error:'Änderung konnte nicht gespeichert werden.'},503)}
}
