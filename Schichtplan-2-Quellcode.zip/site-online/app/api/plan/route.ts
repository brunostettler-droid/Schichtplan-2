import { database } from '@/db';
import { closureReason } from '@/lib/closures';
import employees from '@/data/employees.json';
import { ACCESS_HASH } from '@/lib/access';
export const dynamic = 'force-dynamic';
const reply = (body: unknown, status=200, cookie?: string) => Response.json(body, {status, headers:{'Cache-Control':'no-store', ...(cookie ? {'Set-Cookie':cookie} : {})}});
async function allowed(req: Request) {
  const key = req.headers.get('X-Plan-Key') || '';
  if (key.length > 100) return false;
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(key));
  return Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('') === ACCESS_HASH;
}
function actor(req: Request) { return /(?:^|;\s*)thaifood_actor=([a-f0-9-]{36})(?:;|$)/.exec(req.headers.get('Cookie')||'')?.[1]; }
export async function GET(req: Request) {
  if (!await allowed(req)) return reply({error:'Bitte öffne den vollständigen Gruppenlink aus WhatsApp.'},403);
  const existing = actor(req), identity = existing || crypto.randomUUID();
  try {
    const db = await database();
    const {results} = await db.prepare('SELECT id,date,period,role,time,position,name,fixed,disabled,updated,CASE WHEN owner = ? AND updated > ? THEN 1 ELSE 0 END AS canCancel,CASE WHEN owner = ? THEN 1 ELSE 0 END AS mine FROM shifts ORDER BY date,position').bind(identity,new Date(Date.now()-86400000).toISOString(),identity).all();
    return reply({shifts:results.map(s=>({...s,closureReason:closureReason(String(s.date),String(s.period))})),employees,checkedAt:new Date().toISOString()},200,existing?undefined:`thaifood_actor=${identity}; HttpOnly; SameSite=Strict; Path=/; Max-Age=31536000${new URL(req.url).protocol==='https:'?'; Secure':''}`);
  } catch(e) { console.error(e); return reply({error:'Der Plan konnte nicht geladen werden. Bitte versuche es erneut.'},503); }
}
export async function POST(req: Request) {
  if (!await allowed(req)) return reply({error:'Der Gruppenlink fehlt oder ist ungültig.'},403);
  if (req.headers.get('Origin') !== new URL(req.url).origin) return reply({error:'Ungültige Anfrage.'},403);
  const identity=actor(req);
  if (!identity) return reply({error:'Bitte lade den Plan neu und erlaube Cookies.'},401);
  try {
    const raw=await req.text(); if(raw.length>1000) return reply({error:'Eingabe zu lang.'},400);
    let b;try{b=JSON.parse(raw);}catch{return reply({error:'Ungültige Eingabe.'},400);}
    if(typeof b.id!=='string'||!/^2026-12-\d{2}-\d{1,2}$/.test(b.id)||!['book','cancel'].includes(b.action)) return reply({error:'Ungültige Schicht.'},400);
    const name=typeof b.name==='string'?b.name.trim().replace(/\s+/g,' '):'';
    if(b.action==='book' && (name.length<2||name.length>40||/[\x00-\x1F<>]/.test(name))) return reply({error:'Bitte gib einen Namen mit 2 bis 40 Zeichen ein.'},400);
    const db=await database(),now=new Date().toISOString(),cutoff=new Date(Date.now()-86400000).toISOString();
    const result=b.action==='book'
      ?b.courier===true
        ?await db.prepare(`UPDATE shifts SET name=?,owner=?,updated=? WHERE id=? AND name IS NULL AND disabled=0 AND fixed=0 AND role='Kurier' AND NOT EXISTS (SELECT 1 FROM shifts AS booked WHERE booked.date=shifts.date AND booked.period=shifts.period AND booked.role='Kurier' AND booked.disabled=0 AND booked.name IS NOT NULL AND (booked.owner=? OR lower(booked.name)=lower(?)))`).bind(name,identity,now,b.id,identity,name).run()
        :await db.prepare('UPDATE shifts SET name=?,owner=?,updated=? WHERE id=? AND name IS NULL AND disabled=0 AND fixed=0').bind(name,identity,now,b.id).run()
      :await db.prepare('UPDATE shifts SET name=NULL,owner=NULL,updated=? WHERE id=? AND owner=? AND disabled=0 AND fixed=0 AND name IS NOT NULL AND updated > ?').bind(now,b.id,identity,cutoff).run();
    if(!result.meta.changes) return reply({error:b.action==='book'?b.courier===true?'Dieser Platz ist belegt oder du hast an diesem Tag bereits eine Schicht für Mittag bzw. Abend. Bitte aktualisiere den Plan.':'Dieser Platz ist inzwischen belegt. Bitte aktualisiere den Plan.':'Du kannst nur eigene Einträge innerhalb von 24 Stunden auf demselben Gerät zurückziehen. Danach kann nur der Administrator die Schicht ändern.'},409);
    return reply({ok:true});
  }catch(e){console.error(e);return reply({error:'Speichern fehlgeschlagen. Bitte aktualisiere den Plan, bevor du es erneut versuchst.'},503);}
}
