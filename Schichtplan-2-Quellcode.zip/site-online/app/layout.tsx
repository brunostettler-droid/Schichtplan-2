import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Thaifood · Dezember 2026',description:'Der gemeinsame Schichtplan für unser Thaifood-Team. Freie Plätze ansehen und eintragen.',robots:{index:false,follow:false},referrer:'no-referrer',manifest:'/manifest.webmanifest',appleWebApp:{capable:true,title:'Schichtplan',statusBarStyle:'default'},icons:{icon:'/favicon.svg',shortcut:'/favicon.svg',apple:'/app-180.png'}};
export const viewport:Viewport={width:'device-width',initialScale:1,themeColor:'#175840'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="de-CH"><body>{children}</body></html>;}
