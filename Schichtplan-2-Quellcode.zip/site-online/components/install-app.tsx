'use client';
import { useEffect, useState } from 'react';
import { Download, X } from 'lucide-react';
type InstallEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };
export default function InstallApp() {
  const [prompt, setPrompt] = useState<InstallEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [help, setHelp] = useState(false);
  const [message, setMessage] = useState('');
  const [copyLink, setCopyLink] = useState('');
  useEffect(() => {
    const standalone = window.matchMedia('(display-mode: standalone)');
    const sync = () => setInstalled(standalone.matches || !!(navigator as Navigator & { standalone?: boolean }).standalone);
    sync();
    const ready = (event: Event) => { event.preventDefault(); setPrompt(event as InstallEvent); };
    const done = () => { setInstalled(true); setPrompt(null); setHelp(false); };
    window.addEventListener('beforeinstallprompt', ready);
    window.addEventListener('appinstalled', done);
    standalone.addEventListener('change', sync);
    if ('serviceWorker' in navigator) void navigator.serviceWorker.register('/sw.js').catch(() => {});
    return () => { window.removeEventListener('beforeinstallprompt', ready); window.removeEventListener('appinstalled', done); standalone.removeEventListener('change', sync); };
  }, []);
  async function install() {
    if (!prompt) { setHelp(true); return; }
    try { await prompt.prompt(); await prompt.userChoice; setPrompt(null); }
    catch { setHelp(true); }
  }
  async function copy() {
    const key = location.hash.slice(1) || localStorage.getItem('thaifood_key') || sessionStorage.getItem('thaifood_key') || '';
    const link = location.origin + '/mitarbeiter' + (key ? '#' + key : '');
    setCopyLink(link);
    setMessage('Link wird kopiert … Safari öffnet sich dadurch nicht automatisch.');
    const success = 'Link kopiert ✓ Jetzt zum Startbildschirm wechseln und Safari öffnen. Die Adresszeile antippen, gedrückt halten, «Einsetzen» wählen und auf «Los» tippen. Auf Android: Chrome öffnen und «Einfügen» wählen.';
    // Older in-app browsers may block or leave the clipboard promise pending.
    // Keep a selectable URL visible independently of the clipboard result.
    const timer = window.setTimeout(() => setMessage('Falls keine Kopierbestätigung erscheint: Halte den Link im Feld unten gedrückt, wähle «Alles auswählen» und dann «Kopieren». Öffne danach Safari oder Chrome.'), 2000);
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(link);
      window.clearTimeout(timer);
      setMessage(success);
    } catch {
      window.clearTimeout(timer);
      setMessage('Automatisches Kopieren ist hier nicht möglich. Halte den Link im Feld unten gedrückt, wähle «Alles auswählen» und dann «Kopieren». Öffne danach Safari oder Chrome.');
    }
  }
  if (installed) return null;
  return <section className="app-install" aria-label="App installieren">
    <div><strong>Dein Schichtplan als App</strong><span>Direkt vom Startbildschirm öffnen.</span></div>
    <button type="button" onClick={() => void install()}><Download size={18}/> App installieren</button>
    {help && <div className="install-help"><button type="button" className="help-close" aria-label="Installationsanleitung schliessen" onClick={() => setHelp(false)}><X size={18}/></button>
      <h2>Auf dem Handy installieren</h2>
      <h3>1. Den Link aus WhatsApp in Safari oder Chrome öffnen</h3>
      <p>Tippe zuerst auf diesen Button. Der Button kopiert nur den Link. Safari oder Chrome öffnest du danach selbst, wie unten beschrieben.</p>
      <button type="button" onClick={() => void copy()}>Link kopieren – Schritt 1</button>
      {message && <p role="status" aria-live="polite" style={{background:'#fff',border:'2px solid #175840',borderRadius:8,padding:14,fontWeight:600}}>{message}</p>}
      {copyLink && <div><label htmlFor="install-copy-link"><strong>Link zum manuellen Kopieren</strong></label><textarea id="install-copy-link" readOnly value={copyLink} rows={3} onFocus={e=>e.currentTarget.select()} style={{display:'block',width:'100%',fontSize:16,padding:12,margin:'8px 0',border:'1px solid #175840',borderRadius:8}}/><p>Den Link gedrückt halten → «Alles auswählen» → «Kopieren».</p></div>}
      <ol>
        <li><strong>Link kopieren:</strong> Tippe auf den Button oben.</li>
        <li><strong>Zum Startbildschirm deines Handys wechseln:</strong> Wische vom unteren Bildschirmrand nach oben oder drücke die Home-Taste.</li>
        <li><strong>Browser öffnen:</strong> Auf dem iPhone auf <strong>Safari</strong> (blauer Kompass) tippen. Auf Android auf <strong>Chrome</strong> (rotes, gelbes und grünes Symbol mit blauem Kreis) tippen.</li>
        <li><strong>Adresszeile antippen:</strong> Das ist das Feld oben oder unten, in dem eine Internetadresse steht. Markiere bzw. lösche die bisherige Adresse.</li>
        <li><strong>Link einsetzen:</strong> Halte das leere Adressfeld mit dem Finger gedrückt. Wähle <strong>«Einsetzen»</strong> auf dem iPhone oder <strong>«Einfügen»</strong> auf Android.</li>
        <li><strong>Seite öffnen:</strong> Tippe auf <strong>«Los»</strong>, <strong>«Öffnen»</strong> oder den <strong>Pfeil →</strong> auf der Tastatur. Jetzt siehst du den Schichtplan in Safari oder Chrome.</li>
      </ol>
      <h3>2. Den Schichtplan auf dem Startbildschirm speichern</h3>
      <p><strong>iPhone · in Safari:</strong></p>
      <ol>
        <li>Auf <strong>«Teilen»</strong> tippen (Quadrat mit Pfeil nach oben). Falls du das Symbol nicht siehst, öffne das Safari-Menü und wähle «Teilen».</li>
        <li>In der Liste nach unten scrollen und <strong>«Zum Home-Bildschirm»</strong> auswählen.</li>
        <li>Falls angezeigt, <strong>«Als Web-App öffnen»</strong> aktivieren. Auf <strong>«Hinzufügen»</strong> tippen.</li>
      </ol>
      <p><strong>Android · in Chrome:</strong></p>
      <ol>
        <li>Oben rechts auf die <strong>drei Punkte ⋮</strong> tippen.</li>
        <li><strong>«App installieren»</strong> oder <strong>«Zum Startbildschirm hinzufügen»</strong> auswählen und bestätigen.</li>
      </ol>
      <p><strong>Fertig:</strong> Auf deinem Startbildschirm erscheint «Schichtplan». Tippe künftig auf dieses Symbol.</p>
      <p>Falls die App beim ersten Öffnen nach dem Gruppenlink fragt: Halte das Eingabefeld gedrückt, wähle «Einsetzen» oder «Einfügen» und tippe auf «Schichtplan öffnen». Für aktuelle Schichten brauchst du Internet.</p>
    </div>}
  </section>;
}
