import { env } from 'cloudflare:workers';
import { fixedAssignments } from '@/lib/fixed-shifts';
import { closureReason } from '@/lib/closures';
import seed from '@/data/december.json';
import employees from '@/data/employees.json';
export async function database() {
  if (!env.DB) throw new Error('Datenbank nicht verfügbar');
  const db = env.DB;
  if (!await db.prepare('SELECT id FROM imports WHERE id = ?').bind('december2026').first()) {
    const now = new Date().toISOString();
    await db.batch([
      ...seed.map(s => db.prepare('INSERT OR IGNORE INTO shifts (id,date,period,role,time,position,name,disabled,updated) VALUES (?,?,?,?,?,?,?,?,?)').bind(s.id,s.date,s.period,s.role,s.time,s.position,s.name,s.disabled?1:0,now)),
      db.prepare('INSERT OR IGNORE INTO imports (id) VALUES (?)').bind('december2026'),
    ]);
  }
  if (!await db.prepare('SELECT id FROM imports WHERE id = ?').bind('employees2026').first()) {
    await db.batch([...employees.map(name=>db.prepare('INSERT OR IGNORE INTO employees(name) VALUES (?)').bind(name)),db.prepare('INSERT OR IGNORE INTO imports(id) VALUES (?)').bind('employees2026')]);
  }
  if (!await db.prepare('SELECT id FROM imports WHERE id = ?').bind('fixed-weekly-december2026-v1').first()) {
    const assignments=fixedAssignments(2026,12), now=new Date().toISOString();
    await db.batch([
      ...[...new Set(assignments.map(s=>s.name))].map(name=>db.prepare('INSERT OR IGNORE INTO employees(name) VALUES (?)').bind(name)),
      ...assignments.map(s=>db.prepare('UPDATE shifts SET name=?,fixed=1,owner=NULL,updated=? WHERE id=? AND disabled=0 AND NOT EXISTS (SELECT 1 FROM imports WHERE id=?)').bind(s.name,now,s.id,'fixed-weekly-december2026-v1')),
      db.prepare('INSERT OR IGNORE INTO imports(id) VALUES (?)').bind('fixed-weekly-december2026-v1'),
    ]);
  }
  // Apply the recurring business calendar to every month present in the plan.
  // Existing names are retained in storage; closed shifts cannot be edited/booked.
  const {results:open}=await db.prepare('SELECT DISTINCT date,period FROM shifts WHERE disabled=0').all<{date:string;period:string}>();
  const closed=open.filter(s=>closureReason(s.date,s.period));
  if(closed.length){
    const now=new Date().toISOString();
    await db.batch(closed.map(s=>db.prepare('UPDATE shifts SET disabled=1,updated=? WHERE date=? AND period=? AND disabled=0').bind(now,s.date,s.period)));
  }
  return db;
}
