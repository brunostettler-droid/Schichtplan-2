import { env } from 'cloudflare:workers';
import seed from '@/data/december.json';
import employees from '@/data/employees.json';
export async function database() {
  if (!env.DB) throw new Error('Datenbank nicht verfügbar');
  const db = env.DB;
  if (!await db.prepare('SELECT id FROM imports WHERE id = ?').bind('december2026').first()) {
    const now = new Date().toISOString();
    await db.batch([
      ...seed.map(s => db.prepare('INSERT OR IGNORE INTO shifts (id,date,period,role,time,position,name,disabled,updated) VALUES (?,?,?,?,?,?,?,?,?)').bind(s.id,s.date,s.period,s.role,s.time,s.position,s.name,s.disabled?1:0,now)),
      db.prepare('INSERT OR IGNORE INTO imports (id) VALUES (?)').bind('december2026'),
    ]);
  }
  if (!await db.prepare('SELECT id FROM imports WHERE id = ?').bind('employees2026').first()) {
    await db.batch([...employees.map(name=>db.prepare('INSERT OR IGNORE INTO employees(name) VALUES (?)').bind(name)),db.prepare('INSERT OR IGNORE INTO imports(id) VALUES (?)').bind('employees2026')]);
  }
  return db;
}
