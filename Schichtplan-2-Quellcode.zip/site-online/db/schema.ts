import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const shifts = sqliteTable('shifts', {
  id: text('id').primaryKey(), date: text('date').notNull(), period: text('period').notNull(),
  role: text('role').notNull(), time: text('time'), position: integer('position').notNull(),
  name: text('name'), disabled: integer('disabled').notNull().default(0), owner: text('owner'),
  updated: text('updated').notNull(),
});
export const imports = sqliteTable('imports', { id: text('id').primaryKey() });

export const employees = sqliteTable('employees', {name:text('name').primaryKey()});
