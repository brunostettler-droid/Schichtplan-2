CREATE TABLE `imports` (
	`id` text PRIMARY KEY NOT NULL
);
--> statement-breakpoint
CREATE TABLE `shifts` (
	`id` text PRIMARY KEY NOT NULL,
	`date` text NOT NULL,
	`period` text NOT NULL,
	`role` text NOT NULL,
	`time` text,
	`position` integer NOT NULL,
	`name` text,
	`disabled` integer DEFAULT 0 NOT NULL,
	`owner` text,
	`updated` text NOT NULL
);
