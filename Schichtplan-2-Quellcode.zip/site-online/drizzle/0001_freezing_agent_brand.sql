CREATE TABLE `employees` (
	`name` text PRIMARY KEY NOT NULL
);
