export type Closure={date:string;period:'Mittag'|'Abend';reason:string};
const iso=(date:Date)=>date.toISOString().slice(0,10);
function easterSunday(year:number){
 const a=year%19,b=Math.floor(year/100),c=year%100,d=Math.floor(b/4),e=b%4;
 const f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30;
 const i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451);
 const month=Math.floor((h+l-7*m+114)/31),day=(h+l-7*m+114)%31+1;
 return new Date(Date.UTC(year,month-1,day));
}
export function annualClosures(year:number):Closure[]{
 const closures:Closure[]=[];
 const add=(date:Date,reason:string,allDay=true)=>{closures.push({date:iso(date),period:'Mittag',reason});if(allDay)closures.push({date:iso(date),period:'Abend',reason});};
 const fixed=(month:number,day:number,reason:string,allDay=true)=>add(new Date(Date.UTC(year,month-1,day)),reason,allDay);
 const easter=easterSunday(year),offset=(days:number)=>new Date(easter.getTime()+days*86400000);
 fixed(1,1,'Neujahr');fixed(1,2,'2. Januar – mittags geschlossen',false);
 add(easter,'Ostersonntag');add(offset(1),'Ostermontag – mittags geschlossen',false);
 add(offset(49),'Pfingstsonntag');add(offset(50),'Pfingstmontag – mittags geschlossen',false);
 fixed(8,1,'1. August');
 const lastMonday=new Date(Date.UTC(year,10,30));lastMonday.setUTCDate(30-(lastMonday.getUTCDay()+6)%7);
 add(lastMonday,'Zibelemärit');
 fixed(12,24,'Heiligabend');fixed(12,25,'Weihnachten');fixed(12,26,'26. Dezember – mittags geschlossen',false);fixed(12,31,'Silvester');
 return closures.sort((a,b)=>a.date.localeCompare(b.date)||a.period.localeCompare(b.period));
}
const cache=new Map<number,Map<string,string>>();
export function closureReason(date:string,period:string){
 const year=Number(date.slice(0,4));
 if(!Number.isInteger(year)||year<1583||year>9999)return null;
 if(!cache.has(year))cache.set(year,new Map(annualClosures(year).map(c=>[`${c.date}|${c.period}`,c.reason])));
 return cache.get(year)!.get(`${date}|${period}`)??null;
}
