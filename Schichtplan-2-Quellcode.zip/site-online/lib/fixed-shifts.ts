import weekly from '@/data/fixed-weekly.json';
export function fixedAssignments(year:number, month:number){
 const result:{id:string;name:string}[]=[];
 const days=new Date(Date.UTC(year,month,0)).getUTCDate();
 for(let day=1;day<=days;day++){
  const weekday=(new Date(Date.UTC(year,month-1,day)).getUTCDay()+6)%7;
  const roster:Record<string,string>={...(weekly as Record<string,Record<string,string>>)[String(weekday)]};
  const occurrence=Math.ceil(day/7);
  if(weekday===5){
   if(occurrence%2===1)roster['11']='Javier';
   if(occurrence!==2)roster[occurrence%2===1?'12':'11']='Emin';
  }
  if(weekday===6){
   const saturdayDay=day-1;
   if(saturdayDay>=1&&Math.ceil(saturdayDay/7)===2)delete roster['12'];
  }
  for(const [position,name] of Object.entries(roster))result.push({id:`${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}-${position}`,name});
 }
 return result;
}
