// Network-only: staff names, credentials and shift data are never cached.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  if (event.request.mode !== 'navigate' || event.request.method !== 'GET') return;
  event.respondWith(fetch(event.request).catch(() => new Response(
    '<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Schichtplan · Offline</title><body style="font:18px Arial;padding:32px;max-width:480px;margin:auto"><h1>Du bist offline</h1><p>Für den aktuellen Schichtplan und deine Eintragung brauchst du eine Internetverbindung.</p><button onclick="location.reload()" style="font:inherit;padding:12px">Erneut versuchen</button></body></html>',
    {status: 503, headers: {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store'}}
  )));
});
